BitLocker + Cloud Reset Script (ThinkPad-Ready)
-----------------------------------------------

This script will:
- Auto-elevate to Admin
- Check BitLocker and disable it if active
- Wait for full decryption if needed
- Enable Windows Recovery Environment (WinRE)
- Launch the Reset this PC interface

INSTRUCTIONS (Zoom Guide):
1. Double-click 'run_clean_reset.bat'
2. Let the script handle BitLocker decryption (may take time)
3. On reset screen, guide the user to:
   - Select "Remove everything"
   - Select "Cloud download"
   - Confirm and proceed

NOTES:
- Cloud download pulls a fresh copy of Windows from Microsoft.
- This works even on ThinkPads or other systems WITHOUT a built-in recovery image.
- Make sure the device is plugged in and connected to Wi-Fi.

Safe for employee handoff: they get a fresh, personal-use-ready laptop.
