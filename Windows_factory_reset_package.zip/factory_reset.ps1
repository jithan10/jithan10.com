\
# PowerShell script to initiate a factory reset with 'Remove Everything'

Write-Host "Starting Windows Factory Reset (Remove Everything)..."

Start-Process "systemreset.exe" -ArgumentList "-factoryreset" -Verb runAs
