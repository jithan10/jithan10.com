\
Windows Factory Reset Script (Remove Everything)
------------------------------------------------

This script launches the Windows factory reset tool with the "Remove Everything" option.

Usage:
1. Right-click `run_reset.bat` and choose "Run as Administrator".
2. Follow the prompts to confirm the reset.
3. Choose "Remove everything" when prompted.

Note:
- This script does not bypass the Windows confirmation GUI.
- For a truly silent reset, Windows Deployment Tools or Intune are required.

Use responsibly.
