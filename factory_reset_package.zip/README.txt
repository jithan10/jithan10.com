Fleet Wipe Script (Semi-Silent Factory Reset)
---------------------------------------------

This script sets up a full system wipe (removes all data) using Windows Recovery.

Usage:
1. Right-click `deploy_reset.bat` and choose "Run as Administrator".
2. The script will:
   - Copy the reset config to Windows Recovery settings.
   - Enable WinRE if needed.
   - Reboot into recovery mode.
3. On reboot, Windows will use the config and initiate a full factory reset.

Requirements:
- Windows Recovery Environment (WinRE) must be present and functional.
- Script must be run as Administrator.

Use with caution. This will wipe all data.
