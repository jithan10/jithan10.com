Simplified Clean Reset Script (BitLocker Off)
---------------------------------------------

This script will:
- Auto-elevate to Administrator
- Launch the Windows Reset tool (Remove Everything recommended)

Instructions:
1. Double-click 'run_clean_reset.bat'
2. Wait a few seconds for the Reset window to appear
3. On Zoom, walk the user through:
   - "Remove everything"
   - "Cloud download"

NOTE:
- BitLocker is already OFF on this machine.
- If nothing happens after launch, manually run:
  `systemreset -factoryreset` in CMD or PowerShell.

Make sure the device is plugged in and connected to Wi-Fi before running.
