Final Logging Version - Clean Reset Script
------------------------------------------

This version logs all steps to reset_log.txt and handles elevation properly.

Includes:
- BitLocker status check and disable
- Full logging before and after privilege elevation
- Launches Windows Reset Tool (Cloud Download compatible)

Perfect for remote handoff and confirmation of success.
