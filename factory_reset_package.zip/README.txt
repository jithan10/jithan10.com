Zoom-Guided Windows Clean Reset (with BitLocker Disable)
---------------------------------------------------------

This script will:
- Disable BitLocker on the main drive (if enabled)
- Enable Windows Recovery Environment
- Launch the Windows Reset window

Usage:
1. Double-click 'run_clean_reset.bat'
   (It will auto-elevate to run as Administrator)
2. On Zoom, walk the user through:
   - "Remove everything"
   - "Cloud download"
   - Confirm the prompts

NOTE:
- If BitLocker is ON, the script will fully decrypt the drive before resetting.
- This may take several minutes depending on the drive size.

Make sure the device is plugged in and connected to Wi-Fi before running.
